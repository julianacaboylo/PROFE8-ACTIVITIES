# Car Rental Mobile Application

A comprehensive Flutter mobile application for car rental business that demonstrates advanced navigation, state management, and media features.

## Features Implemented

### Activity 3 - Navigation Features
1. ✅ **Two screens with Navigator.push() and Navigator.pop()** - Login to Home navigation
2. ✅ **Drawer menu with three different pages** - Home, About, Contact navigation
3. ✅ **BottomNavigationBar with three tabs** - Home, Cart, Profile
4. ✅ **TabBar with TabBarView** - Cars, Featured, Deals tabs in home screen
5. ✅ **Icons in BottomNavigationBar** - Each tab has appropriate icons
6. ✅ **Combined Drawer and BottomNavigationBar** - Both navigation methods in home screen

### Activity 4 - Advanced Navigation
1. ✅ **Two screens with push() and pop()** - Car details navigation
2. ✅ **Drawer menu navigation** - Multiple pages accessible via drawer
3. ✅ **BottomNavigationBar implementation** - Three main sections
4. ✅ **TabBar with TabBarView** - Three tabs in home screen
5. ✅ **Icons in BottomNavigationBar** - Visual navigation indicators
6. ✅ **Combined navigation** - Drawer + BottomNav in same app
7. ✅ **Named routes** - Home, About, Contact routes defined
8. ✅ **push() vs pushReplacement()** - Login uses pushReplacement, others use push
9. ✅ **TabBar in AppBar** - Three tabs: Cars, Featured, Deals
10. ✅ **Login to Home flow** - Login screen navigates to home with Drawer and BottomNav

### Activity 5 - Provider State Management & Media
1. ✅ **Shopping cart with Provider** - Add/remove cars with state management
2. ✅ **ChangeNotifier with Provider** - Real-time UI updates
3. ✅ **context.read() vs context.watch()** - Demonstrated in cart screen
4. ✅ **Theme switcher with Provider** - Dark/light mode toggle
5. ✅ **Todo list with Provider** - Complete CRUD operations
6. ✅ **Local image with Image.asset()** - Placeholder car image
7. ✅ **Network image with Image.network()** - Car images from URLs
8. ✅ **Circular border to image** - BoxDecoration for styled images
9. ✅ **GridView with images** - Gallery screen with grid layout
10. ✅ **Video player** - video_player package implementation
11. ✅ **Enhanced video controls** - chewie package integration
12. ✅ **Audio player** - audioplayers package with controls
13. ✅ **Material Icons with dynamic color/size** - Profile screen icons
14. ✅ **Custom icon usage** - Various icons throughout the app
15. ✅ **Custom fonts** - Ready for Roboto and Poppins (commented out)
16. ✅ **Two different text styles** - Various font weights and sizes
17. ✅ **Profile card** - Image, custom icons, and styled text
18. ✅ **Gallery/carousel** - Image carousel with indicators
19. ✅ **Video + Audio player** - Combined media player with controls

## Project Structure

```
lib/
├── main.dart                 # App entry point with named routes
├── providers/               # State management
│   ├── cart_provider.dart   # Shopping cart logic
│   ├── theme_provider.dart  # Theme management
│   └── todo_provider.dart   # Todo list logic
├── screens/               # UI screens
│   ├── login_screen.dart     # Login with pushReplacement
│   ├── home_screen.dart     # Main screen with Drawer + BottomNav + TabBar
│   ├── car_details_screen.dart # Car details with push navigation
│   ├── about_screen.dart     # About page
│   ├── contact_screen.dart   # Contact page with form
│   ├── cart_screen.dart      # Shopping cart with Provider
│   ├── todo_screen.dart      # Todo list with Provider
│   ├── media_screen.dart     # Video and audio players
│   ├── gallery_screen.dart   # Image gallery and carousel
│   └── profile_screen.dart   # Profile with custom icons
└── models/                  # Data models
    └── car_data.dart        # Car information

assets/
├── images/                  # Local images
├── videos/                  # Video files
└── audio/                   # Audio files
```

## Dependencies

- **provider**: ^6.0.5 - State management
- **video_player**: ^2.7.2 - Video playback
- **chewie**: ^1.6.2 - Enhanced video controls
- **audioplayers**: ^5.0.3 - Audio playback
- **http**: ^1.1.0 - Network requests

## Getting Started

1. **Install Dependencies**:
   ```bash
   flutter pub get
   ```

2. **Run the App**:
   ```bash
   flutter run
   ```

## Navigation Flow

1. **Login Screen** → Home Screen (pushReplacement)
2. **Home Screen** → Car Details (push)
3. **Drawer Navigation** → About, Contact, Cart, Todo, Media, Gallery, Profile
4. **Bottom Navigation** → Home, Cart, Profile
5. **Tab Navigation** → Cars, Featured, Deals

## Key Features Demonstrated

### Navigation Patterns
- **Navigator.push()** - For forward navigation
- **Navigator.pop()** - For backward navigation
- **Navigator.pushReplacement()** - For login flow
- **Named routes** - For organized navigation
- **Drawer + BottomNav** - Combined navigation methods

### State Management
- **Provider pattern** - Centralized state management
- **ChangeNotifier** - Reactive UI updates
- **context.read()** - For actions and mutations
- **context.watch()** - For UI updates
- **MultiProvider** - Multiple providers in one app

### Media Integration
- **Video Player** - Full-screen video with chewie controls
- **Audio Player** - Background audio playback
- **Image Display** - Local and network images
- **Gallery** - Grid and carousel layouts
- **Circular Images** - Styled image borders

### UI Components
- **Material Icons** - Dynamic color and size changes
- **Custom Styling** - BoxDecoration for borders
- **Theme System** - Complete dark/light mode
- **Responsive Layout** - Adaptive design patterns

## Usage Examples

### Navigation
```dart
// Push navigation
Navigator.push(context, MaterialPageRoute(builder: (context) => NextScreen()));

// Named route navigation
Navigator.pushNamed(context, '/about');

// Push replacement
Navigator.pushReplacementNamed(context, '/home');
```

### State Management
```dart
// Using context.read() for actions
context.read<CartProvider>().addItem(car);

// Using context.watch() for UI updates
Consumer<CartProvider>(
  builder: (context, cartProvider, child) {
    return Text('Items: ${cartProvider.itemCount}');
  },
)
```

### Theme Switching
```dart
// Toggle theme mode
themeProvider.setThemeMode(
  themeProvider.themeMode == ThemeMode.dark
      ? ThemeMode.light
      : ThemeMode.dark,
);
```

## Customization

### Adding New Cars
Edit `lib/models/car_data.dart` to add more vehicles:
```dart
CarItem(
  id: '9',
  name: 'New Car Model',
  image: 'https://example.com/image.jpg',
  price: 100.0,
  description: 'Car description',
  category: 'Economy',
),
```

### Adding Custom Fonts
1. Add font files to `assets/fonts/`
2. Uncomment font references in `pubspec.yaml`
3. Uncomment fontFamily properties in code

## Testing

Run the test suite:
```bash
flutter test
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please open an issue in the repository.
