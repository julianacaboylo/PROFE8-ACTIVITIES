// Simple script to check for common Flutter errors
void main() {
  print('Checking for common Flutter project issues...');
  print('1. Import paths - should be relative for local files');
  print('2. Missing dependencies - check pubspec.yaml');
  print('3. Syntax errors - check for missing semicolons, brackets');
  print('4. Route parameters - ensure all routes have required parameters');
  print('5. Provider usage - ensure all providers are properly imported');
}
