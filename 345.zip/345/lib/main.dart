import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/cart_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/todo_provider.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/about_screen.dart';
import 'screens/contact_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/todo_screen.dart';
import 'screens/media_screen.dart';
import 'screens/gallery_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/push_demo_a.dart';
import 'screens/push_demo_b.dart';
import 'screens/tabs_screen.dart';

void main() {
  runApp(const CarRentalApp());
}

class CarRentalApp extends StatelessWidget {
  const CarRentalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => TodoProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            title: 'Car Rental App',
            theme: themeProvider.lightTheme,
            darkTheme: themeProvider.darkTheme,
            themeMode: themeProvider.themeMode,
            debugShowCheckedModeBanner: false,
            // Named routes for Activity 4
            routes: {
              '/': (context) => const LoginScreen(),
              '/home': (context) => const HomeScreen(),
              '/about': (context) => const AboutScreen(),
              '/contact': (context) => const ContactScreen(),
              '/car-details': (context) {
                // This route requires a car parameter, so we'll handle it differently
                return const Scaffold(
                  body: Center(
                    child: Text('Car details route - use Navigator.push with car parameter'),
                  ),
                );
              },
              '/cart': (context) => const CartScreen(),
              '/todo': (context) => const TodoScreen(),
              '/media': (context) => const MediaScreen(),
              '/gallery': (context) => const GalleryScreen(),
              '/profile': (context) => const ProfileScreen(),
              '/push-a': (context) => const PushDemoA(),
              '/push-b': (context) => const PushDemoB(),
              '/tabs': (context) => const TabsScreen(),
            },
          );
        },
      ),
    );
  }
}
