import 'package:flutter/material.dart';

class PushDemoA extends StatelessWidget {
  const PushDemoA({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Push Demo A')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Screen A'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // push to Screen B
                Navigator.pushNamed(context, '/push-b');
              },
              child: const Text('Push to B (push)'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // pushReplacement to Screen B
                Navigator.pushReplacementNamed(context, '/push-b');
              },
              child: const Text('PushReplacement to B'),
            ),
          ],
        ),
      ),
    );
  }
}
