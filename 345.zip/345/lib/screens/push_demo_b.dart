import 'package:flutter/material.dart';

class PushDemoB extends StatelessWidget {
  const PushDemoB({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Push Demo B')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Screen B'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Go Back (pop)'),
            ),
          ],
        ),
      ),
    );
  }
}
