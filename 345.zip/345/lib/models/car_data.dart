import 'package:car_rental_app/providers/cart_provider.dart';

class CarData {
  static final List<CarItem> availableCars = [
    CarItem(
      id: '1',
      name: 'BMW X5',
      image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400',
      price: 150.0,
      description: 'Luxury SUV with premium features',
      category: 'Luxury',
    ),
    CarItem(
      id: '2',
      name: 'Mercedes C-Class',
      image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=400',
      price: 120.0,
      description: 'Elegant sedan with advanced technology',
      category: 'Luxury',
    ),
    CarItem(
      id: '3',
      name: 'Audi A4',
      image: 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=400',
      price: 110.0,
      description: 'Sporty sedan with quattro all-wheel drive',
      category: 'Luxury',
    ),
    CarItem(
      id: '4',
      name: 'Tesla Model 3',
      image: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400',
      price: 180.0,
      description: 'Electric vehicle with autopilot features',
      category: 'Electric',
    ),
    CarItem(
      id: '5',
      name: 'Toyota Camry',
      image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400',
      price: 80.0,
      description: 'Reliable sedan perfect for daily commuting',
      category: 'Economy',
    ),
    CarItem(
      id: '6',
      name: 'Honda Civic',
      image: 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=400',
      price: 70.0,
      description: 'Fuel-efficient compact car',
      category: 'Economy',
    ),
    CarItem(
      id: '7',
      name: 'Ford Mustang',
      image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400',
      price: 200.0,
      description: 'American muscle car with powerful engine',
      category: 'Sports',
    ),
    CarItem(
      id: '8',
      name: 'Porsche 911',
      image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=400',
      price: 350.0,
      description: 'High-performance sports car',
      category: 'Sports',
    ),
  ];
}
