import 'package:flutter/material.dart';

class CarItem {
  final String id;
  final String name;
  final String image;
  final double price;
  final String description;
  final String category;

  CarItem({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    required this.description,
    required this.category,
  });
}

class CartItem {
  final CarItem car;
  int quantity;

  CartItem({required this.car, this.quantity = 1});
}

class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => _items;
  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);
  double get totalPrice => _items.fold(0, (sum, item) => sum + (item.car.price * item.quantity));

  void addItem(CarItem car) {
    final existingIndex = _items.indexWhere((item) => item.car.id == car.id);
    
    if (existingIndex >= 0) {
      _items[existingIndex].quantity++;
    } else {
      _items.add(CartItem(car: car));
    }
    notifyListeners();
  }

  void removeItem(String carId) {
    _items.removeWhere((item) => item.car.id == carId);
    notifyListeners();
  }

  void updateQuantity(String carId, int quantity) {
    final index = _items.indexWhere((item) => item.car.id == carId);
    if (index >= 0) {
      if (quantity <= 0) {
        _items.removeAt(index);
      } else {
        _items[index].quantity = quantity;
      }
      notifyListeners();
    }
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}
