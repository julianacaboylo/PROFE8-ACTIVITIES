import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:car_rental_app/main.dart';
import 'package:car_rental_app/providers/cart_provider.dart';
import 'package:car_rental_app/providers/theme_provider.dart';
import 'package:car_rental_app/providers/todo_provider.dart';

void main() {
  testWidgets('App starts without crashing', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const CarRentalApp());

    // Verify that the app starts
    expect(find.text('Car Rental App'), findsOneWidget);
  });

  testWidgets('Provider providers work correctly', (WidgetTester tester) async {
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => CartProvider()),
          ChangeNotifierProvider(create: (_) => ThemeProvider()),
          ChangeNotifierProvider(create: (_) => TodoProvider()),
        ],
        child: MaterialApp(
          home: Scaffold(
            body: Consumer<CartProvider>(
              builder: (context, cartProvider, child) {
                return Text('Items: ${cartProvider.itemCount}');
              },
            ),
          ),
        ),
      ),
    );

    // Verify that the provider works
    expect(find.text('Items: 0'), findsOneWidget);
  });
}
