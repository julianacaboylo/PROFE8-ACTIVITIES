import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BookingForm extends StatefulWidget {
  const BookingForm({super.key});

  @override
  _BookingFormState createState() => _BookingFormState();
}

class _BookingFormState extends State<BookingForm> {
  final _formKey = GlobalKey<FormState>();
  String selectedCar = '';
  bool addInsurance = false;
  bool gps = false;
  String role = 'Customer';
  DateTime? rentalDate;
  TimeOfDay? rentalTime;
  final notesController = TextEditingController();

  final List<Map<String, dynamic>> availableCars = [
    {
      'id': 'bmw_x5',
      'name': 'BMW X5',
  'price': '₱89/day',
      'icon': Icons.directions_car,
      'color': const Color(0xFF2563EB),
      'features': ['Automatic', '4WD', 'GPS', 'Leather Seats'],
      'category': 'Luxury SUV'
    },
    {
      'id': 'mercedes_c',
      'name': 'Mercedes C-Class',
  'price': '₱75/day',
      'icon': Icons.directions_car,
      'color': const Color(0xFF7C3AED),
      'features': ['Automatic', 'Luxury', 'Bluetooth', 'Sunroof'],
      'category': 'Luxury Sedan'
    },
    {
      'id': 'audi_a4',
      'name': 'Audi A4',
  'price': '₱65/day',
      'icon': Icons.directions_car,
      'color': const Color(0xFF059669),
      'features': ['Automatic', 'Premium', 'Sunroof', 'Navigation'],
      'category': 'Premium Sedan'
    },
    {
      'id': 'toyota_camry',
      'name': 'Toyota Camry',
  'price': '₱45/day',
      'icon': Icons.directions_car,
      'color': const Color(0xFFDC2626),
      'features': ['Automatic', 'Economy', 'Bluetooth', 'Backup Camera'],
      'category': 'Economy Sedan'
    },
    {
      'id': 'honda_crv',
      'name': 'Honda CR-V',
  'price': '₱55/day',
      'icon': Icons.directions_car,
      'color': const Color(0xFFEA580C),
      'features': ['Automatic', 'SUV', 'AWD', 'Spacious'],
      'category': 'Compact SUV'
    },
    {
      'id': 'tesla_model3',
      'name': 'Tesla Model 3',
  'price': '₱95/day',
      'icon': Icons.electric_car,
      'color': const Color(0xFF10B981),
      'features': ['Electric', 'Autopilot', 'Premium', 'Fast Charging'],
      'category': 'Electric Vehicle'
    },
  ];

  @override
  void initState() {
    super.initState();
    selectedCar = availableCars.first['id'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Book a Car"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Hero Section
            Container(
              height: 200,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF2563EB),
                    Color(0xFF1D4ED8),
                  ],
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.directions_car,
                      size: 48,
                      color: Colors.white,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose Your Perfect Ride',
                      style: GoogleFonts.inter(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Car Selection
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Select a Car',
                    style: GoogleFonts.inter(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF1F2937),
                    ),
                  ),
                  const SizedBox(height: 16),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.8,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    itemCount: availableCars.length,
                    itemBuilder: (context, index) {
                      final car = availableCars[index];
                      final isSelected = selectedCar == car['id'];
                      return _buildCarSelectionCard(car, isSelected);
                    },
                  ),
                  const SizedBox(height: 24),
                  // Booking Form
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Booking Details',
                              style: GoogleFonts.inter(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF1F2937),
                              ),
                            ),
                            const SizedBox(height: 20),
                            _buildDateTimeSelector(),
                            const SizedBox(height: 20),
                            _buildOptionsSection(),
                            const SizedBox(height: 20),
                            _buildNotesField(),
                            const SizedBox(height: 24),
                            _buildSubmitButton(),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCarSelectionCard(Map<String, dynamic> car, bool isSelected) {
    return GestureDetector(
      onTap: () => setState(() => selectedCar = car['id']),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? const Color(0xFF2563EB) : const Color(0xFFE5E7EB),
            width: isSelected ? 2 : 1,
          ),
          color: isSelected ? const Color(0xFF2563EB).withOpacity(0.05) : Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: Container(
                height: 100,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF2563EB).withOpacity(0.8),
                      const Color(0xFF1D4ED8).withOpacity(0.9),
                    ],
                  ),
                ),
                child: Stack(
                  children: [
                    // Car icon as placeholder
                    Center(
                      child: Icon(
                        car['icon'] ?? Icons.directions_car,
                        size: 32,
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                    // Car name overlay
                    Positioned(
                      bottom: 4,
                      left: 4,
                      right: 4,
                      child: Text(
                        car['name'],
                        style: GoogleFonts.inter(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    car['name'],
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF1F2937),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    car['price'],
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF2563EB),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    car['category'],
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: const Color(0xFF6B7280),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDateTimeSelector() {
    return Row(
      children: [
        Expanded(
          child: _buildDateButton(),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildTimeButton(),
        ),
      ],
    );
  }

  Widget _buildDateButton() {
    return InkWell(
      onTap: () async {
        DateTime? picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 365)),
        );
        if (picked != null) {
          setState(() => rentalDate = picked);
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE5E7EB)),
          borderRadius: BorderRadius.circular(16),
          color: Colors.white,
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today, color: Color(0xFF6B7280)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                rentalDate == null
                    ? "Select Date"
                    : "${rentalDate!.day}/${rentalDate!.month}/${rentalDate!.year}",
                style: GoogleFonts.inter(
                  color: rentalDate == null ? const Color(0xFF6B7280) : const Color(0xFF1F2937),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeButton() {
    return InkWell(
      onTap: () async {
        TimeOfDay? picked = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );
        if (picked != null) {
          setState(() => rentalTime = picked);
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE5E7EB)),
          borderRadius: BorderRadius.circular(16),
          color: Colors.white,
        ),
        child: Row(
          children: [
            const Icon(Icons.access_time, color: Color(0xFF6B7280)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                rentalTime == null
                    ? "Select Time"
                    : rentalTime!.format(context),
                style: GoogleFonts.inter(
                  color: rentalTime == null ? const Color(0xFF6B7280) : const Color(0xFF1F2937),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionsSection() {
    return Column(
      children: [
        _buildSwitchTile(
          'Add Insurance Coverage',
          'Protect your rental with comprehensive insurance',
          addInsurance,
          (value) => setState(() => addInsurance = value),
          Icons.security,
        ),
        const SizedBox(height: 16),
        _buildSwitchTile(
          'Enable GPS Tracking',
          'Track your vehicle location in real-time',
          gps,
          (value) => setState(() => gps = value),
          Icons.location_on,
        ),
        const SizedBox(height: 16),
        _buildRoleSelector(),
      ],
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, bool value, Function(bool) onChanged, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFE5E7EB)),
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF2563EB).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: const Color(0xFF2563EB), size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1F2937),
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: const Color(0xFF6B7280),
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: const Color(0xFF2563EB),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFE5E7EB)),
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'User Role',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF1F2937),
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: role,
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
            items: ["Customer", "Staff", "Admin"]
                .map((role) => DropdownMenuItem(
                      value: role,
                      child: Text(role),
                    ))
                .toList(),
            onChanged: (val) => setState(() => role = val!),
          ),
        ],
      ),
    );
  }

  Widget _buildNotesField() {
    return TextField(
      controller: notesController,
      maxLines: 3,
      decoration: const InputDecoration(
        labelText: "Special Notes (Optional)",
        prefixIcon: Icon(Icons.note),
        hintText: "Any special requirements or notes...",
      ),
    );
  }

  Widget _buildSubmitButton() {
    final selectedCarData = availableCars.firstWhere((car) => car['id'] == selectedCar);
    
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: const Icon(Icons.check_circle),
        label: Text("Book ${selectedCarData['name']}"),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        onPressed: () {
          _formKey.currentState!.save();
          Navigator.pushNamed(context, '/rentals', arguments: {
            'car': selectedCarData['name'],
            'carImage': selectedCarData['image'],
            'carPrice': selectedCarData['price'],
            'carCategory': selectedCarData['category'],
            'insurance': addInsurance,
            'gps': gps,
            'role': role,
            'date': rentalDate?.toLocal().toString(),
            'time': rentalTime?.format(context),
            'notes': notesController.text,
          });
        },
      ),
    );
  }
}
