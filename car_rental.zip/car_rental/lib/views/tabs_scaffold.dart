import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TabsScaffoldScreen extends StatefulWidget {
  const TabsScaffoldScreen({Key? key}) : super(key: key);

  @override
  _TabsScaffoldScreenState createState() => _TabsScaffoldScreenState();
}

class _TabsScaffoldScreenState extends State<TabsScaffoldScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    Center(child: Text('Home Tab', style: TextStyle(fontSize: 24))),
    Center(child: Text('Profile Tab', style: TextStyle(fontSize: 24))),
    Center(child: Text('Settings Tab', style: TextStyle(fontSize: 24))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bottom Tabs Demo')),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
