import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class DemoNavScreen extends StatelessWidget {
  const DemoNavScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Push vs PushReplacement Demo')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () async {
                // push: returning will show previous route again
                await Navigator.push(context, MaterialPageRoute(builder: (_) => const DemoPage(title: 'Pushed Page')));
              },
              child: const Text('Open with push()'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                // pushReplacement: previous route replaced
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DemoPage(title: 'Replaced Page')));
              },
              child: const Text('Open with pushReplacement()'),
            ),
          ],
        ),
      ),
    );
  }
}

class DemoPage extends StatelessWidget {
  final String title;
  const DemoPage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: ElevatedButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Go Back'),
        ),
      ),
    );
  }
}
