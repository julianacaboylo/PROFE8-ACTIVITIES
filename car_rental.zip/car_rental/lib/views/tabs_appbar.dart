import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TabsAppBarScreen extends StatelessWidget {
  const TabsAppBarScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('AppBar Tabs Demo'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.chat), text: 'Chats'),
              Tab(icon: Icon(Icons.access_time), text: 'Status'),
              Tab(icon: Icon(Icons.call), text: 'Calls'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text('Chats', style: TextStyle(fontSize: 20))),
            Center(child: Text('Status', style: TextStyle(fontSize: 20))),
            Center(child: Text('Calls', style: TextStyle(fontSize: 20))),
          ],
        ),
      ),
    );
  }
}
